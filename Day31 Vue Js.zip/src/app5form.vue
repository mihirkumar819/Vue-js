<template>
    <div>
      <h1>{{ title }}</h1>
      <pre>{{ JSON.stringify(heroinfo, null, 1) }}</pre>
      <form>
          <div class="mb-3">
              <label for="htitle" class="form-label">Hero Title</label>
              <input v-model="heroinfo.title" type="text" class="form-control" id="htitle">
          </div>
          <div class="mb-3">
              <label for="hfname" class="form-label">Hero FirstName</label>
              <input v-model="heroinfo.firstname" type="text" class="form-control" id="hfname">
          </div>
          <div class="mb-3">
              <label for="hlname" class="form-label">Hero LastName</label>
              <input v-model="heroinfo.lastname" type="text" class="form-control" id="hlname">
          </div>
          <div class="mb-3">
              <label for="hcity" class="form-label">Hero City</label>
              <input v-model="heroinfo.city" type="text" class="form-control" id="hcity">
          </div>
          <div class="mb-3">
              <label for="hpower" class="form-label">Hero Power</label>
              <input v-model="heroinfo.power" type="number" class="form-control" id="hpower">
          </div>
          <div class="mb-3">
              <label for="hcf" class="form-label">Hero Can Fly</label>
              <input true-value="can fly" false-value="can't fly" v-model="heroinfo.canfly" type="checkbox" id="hcf">
          </div>
          <div class="mb-3">
              <label for="hgender" class="form-label">Hero's Gender</label>
              <input value="male" name="hgender" v-model="heroinfo.gender" type="radio" id="hgender">
              <input value="female" name="hgender" v-model="heroinfo.gender" type="radio" id="hgender">
          </div>
          <div class="mb-3">
              <label for="hpower" class="form-label">Hero Type</label>
             <select v-model="heroinfo.type">
              <option value="" selected >Select Here</option>
              <option value="avenger"  >Avenger</option>
              <option value="justice_league"  >Justice League</option>
              <option value="indic_hero"  >Indic Hero</option>
             </select>
          </div>
        <button type="submit" class="btn btn-primary">Register</button>
      </form>
    </div>
  </template>
   
  <script>
  export default {
  data(){
    return {
      title : "Forms and Data",
      heroinfo : {
        title : '',
        firstname : '',
        lastname : '',
        city : '',
        power : 0,
        type : '',
        gender : '',
        canfly : ''
      },
   
    }
  }
  }
  </script>
   
  <style></style>
   
  