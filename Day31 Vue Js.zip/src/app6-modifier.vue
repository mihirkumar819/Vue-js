<template>
    <div>
    <h1> {{title}} </h1>
    <hr>
    Power:
    <input v-model.number.lazy="power" type="range">{{power}}
    <hr>
    <br>
    Booster:
    <input v-model.number.lazy="booster" type="range">{{booster}}
    <hr>
    Total Power:{{power+booster}}
    <hr>
    <textarea v-model.trim="message"></textarea>
    <br>
    <p>Message:{{message}}</p>
    </div>
    </template>
    <script>
    export default {
      data(){
          return {
              title:"Modifier",
              power:0,
              booster:0,
              message:''
          }
      }
    }
    </script>
  
    <style>
    </style>
  
  
  
  
  
  
  
  