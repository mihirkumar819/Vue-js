<template>
    <div> 
    <h1> {{title}} </h1>
    <!-- <button v-on:click="myfun">Click Me</button> -->
  
    <!-- /****Allias @: or only @ for v-on *******/ -->
    <button @:click="myfun">Click Me</button>
    <h2>Power is {{power}}</h2>
    <button @:click="power++">increse power</button>
    <button @:click="power--">decrese power</button>
    <hr>
    <button @:click="incresepower">increse power</button>
    <button @:click="decresepower">decrese power</button>
    <hr>
    <!-- Power is <input @input="setPower($event)" type="range"/> -->
    Power is <input @change="setPower($event)" type="range"/>
  
  
  
  
       
    </div>
    </template>
    <script>
    export default {
      data(){
          return {
              title:"Event Method Computed",
              power:0,
          }
      },
      methods:{
        myfun(){
          alert("you clicked me");
        },
        setPower(evt){
          this.power=evt.target.value;
        },
        incresepower(){
          this.power++;
        },
        decresepower(){
          this.power--;
        }
        
        
      }
    }
    </script>
  
    <style>
    </style>