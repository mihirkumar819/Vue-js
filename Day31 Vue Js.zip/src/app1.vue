<template>
    <div>
    <h1> {{title}} </h1>
    <input min="0" max="10" type="range" v-model="power"/>
    <input min="0" max="10" type="number" v-model="power"/>
  
    <!-- <h2 v-if="power ==='1'">Power is 1</h2>
    <h2 v-if="power ==='2'">Power is 2</h2>
    <h2 v-if="power ==='3'">Power is 3</h2>
    <h2 v-if="power ==='4'">Power is 4</h2> -->
    <h2 v-if="power ==='5'">Power is 5</h2>
    <!-- <h2 v-else-if="power >'6'">Power is more</h2> -->
    <h2 v-else>Power is not 5 </h2>
    <!-- <input type="checkbox" v-model="show"/>
    <div v-show="show">
    
        <h2>Company Policy</h2>
    <fieldset>
      <legend>
        Terms and Conditions
      </legend>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus nesciunt praesentium voluptates rem reprehenderit, ab cumque sit? Laboriosam ratione, optio asperiores facere itaque necessitatibus modi minus iusto, expedita doloremque molestias!
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis repudiandae nam, nemo reiciendis deleniti consequuntur ab modi voluptatum nisi eveniet autem, quaerat officia sit, deserunt unde maxime ipsum delectus facere.
      </p>
    </fieldset> -->
    <input type="checkbox" v-model="show"/>
    <div v-show="show">
    
        <h2>Company Policy</h2>
    <fieldset>
      <legend>
        Terms and Conditions
      </legend>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus nesciunt praesentium voluptates rem reprehenderit, ab cumque sit? Laboriosam ratione, optio asperiores facere itaque necessitatibus modi minus iusto, expedita doloremque molestias!
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis repudiandae nam, nemo reiciendis deleniti consequuntur ab modi voluptatum nisi eveniet autem, quaerat officia sit, deserunt unde maxime ipsum delectus facere.
      </p>
    </fieldset>
    <h2 v-show="show">Content with show</h2>
    <h2 v-if="show">Content with if</h2>
  
  
  
  </div>
  
  
  
  </div>
    </template>
    <script>
    export default {
      data(){
          return {
              title:"Welcome to Your Life",
              power:"4",
              show:true
          }
      }
    }
    </script>
  
    <style>
    </style>