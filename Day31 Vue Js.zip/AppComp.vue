<!-- <template>
    <div>
    <h1>{{title}} Version {{version}}</h1>
  </div>
    </template>
    <script>
    export default {
      name:"HomeComp",
      props:['title','version']
    }
    </script>
  
    <style>
    </style>
  
  /******************************************************************************* */

  <!-- <template>
  <div>
  
  <HomeComp :version="appversion" title="Avengers"/>
  <HomeComp :version="appversion" title="Justic League"/>
  <HomeComp :version="appversion" title="Indic Heros"/>


 </div>
  </template>
  <script>
  import HomeComp from './components/home.vue';
  export default {
    data(){
        return {
          power:0,
          appversion:1.5
        }
    },
    components:{
      HomeComp
    }
  }
  </script>

  <style>
  </style>






 -->